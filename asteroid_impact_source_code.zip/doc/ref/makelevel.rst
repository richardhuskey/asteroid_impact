*********
makelevel
*********

:mod:`makelevel`
==============================

.. automodule:: makelevel
   :members:
   :undoc-members:
   :show-inheritance:
