******************
makestandardlevels
******************

:mod:`makestandardlevels`
==============================

.. automodule:: makestandardlevels
   :members:
   :undoc-members:
   :show-inheritance:
