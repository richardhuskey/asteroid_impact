*******
sprites
*******

:mod:`sprites`
==============================

.. automodule:: sprites
   :members:
   :undoc-members:
   :show-inheritance:
